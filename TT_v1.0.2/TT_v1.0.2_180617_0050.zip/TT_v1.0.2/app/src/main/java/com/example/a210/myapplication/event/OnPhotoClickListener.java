package com.example.a210.myapplication.event;

import android.view.View;


public interface OnPhotoClickListener {

  void onClick(View v, int position, boolean showCamera);
}
