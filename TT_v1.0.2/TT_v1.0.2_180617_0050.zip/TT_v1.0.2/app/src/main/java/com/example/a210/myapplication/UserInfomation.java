package com.example.a210.myapplication;

public  class UserInfomation {

    static String User_ID;
    static String User_NickName;
    static Integer User_Age;
    static String User_Sex;
    static String User_Fun;
    static String QuestType;

}
