package com.example.a210.myapplication;

import android.content.Intent;
import android.os.Message;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ChatActivity extends AppCompatActivity{
    ListView chatList;
    Intent it,itGet;
    ChatView adapterItem = new ChatView();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        chatList = (ListView)findViewById(R.id.chatList);
        itGet = getIntent();

        final ChatViewAdapter adapter = new ChatViewAdapter();

        chatList.setAdapter(adapter);

        if(itGet.getStringExtra("sep").toString().equals("quest")) {
            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "누구보다빠르게",
                    "여행박사", "당신이 어디있든 누구보다 빠르게");
            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "태양신",
                    "여행초보", "태양신 추천 여행지");
            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "방랑벽",
                    "여행박사", "목적 없이 걷기 편한 장소 전문");
            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "김삿갓",
                    "태양신", "여행 전문 칼럼니스트입니다.");
            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "서울토박이",
                    "여행중수", "부산, 울산 쪽 답변합니다.");
            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "이승철",
                    "여행박사", "여행지 잘 봤구요 제 점수는요");
        } else if(itGet.getStringExtra("sep").toString().equals("dap")) {


            Thread th = new Thread(new Runnable() {
                @Override
                public void run() {
                    try
                    {
                        String jsonString;
                        String urlString = "http://lim7504.iptime.org:8080/TripTalkWebServer/QuestionSelect.jsp?";
                        urlString += "USER_ID=" + UserInfomation.User_ID;
                        jsonString = TomcatConnector(urlString);

                        JSONArray arr = new JSONArray(jsonString);

                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject obj = arr.getJSONObject(i);

                            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), obj.get("NICK").toString(),
                                    obj.get("GRADE").toString(), obj.get("SUBTITLE").toString());
                        }
                    }
                    catch (Exception e)
                    {
                    }
                }
            });
            th.start();


//            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "리신",
//                    "여행코스", "어디로... 가야하오");
//            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "직거래 살인마",
//                    "관광지", "중고 직거래 가능한 어둡고 아무도 다니지 않는 장소");
//            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "한지우",
//                    "레포츠", "속초에 망나뇽 나오는 곳이 어디죠");
//            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "김정호",
//                    "여행코스", "한반도 최단 거리 코스 좀 알려주세요");
//            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "고든 램지",
//                    "음식점", "어제 한 음식점이 내 혀를 조져놨어요 제대로 된 음식점을 알려주세요");
//            adapter.addItem(getResources().getDrawable(R.drawable.default_face), getResources().getDrawable(R.drawable.newicon), "남조선 국민",
//                    "문화시설", "고조 청와대로 가려면 우찌해야합네까 동무");
        }

        chatList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent it = new Intent(getApplicationContext(),RoomActivity.class);
                Log.i("getItem",adapter.getChatViewItem(i).getNick());
                it.putExtra("nick", adapter.getChatViewItem(i).getNick().toString());
                it.putExtra("grade", adapter.getChatViewItem(i).getGrade().toString());
                startActivity(it);
            }
        });

        callFragment(1);
        callFragment(2);
    }

    private void callFragment(int frament_no) {

        // 프래그먼트 사용을 위해
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        switch (frament_no) {
            case 1:
                // '프래그먼트1' 호출
                Footer fragment1 = new Footer();
                Bundle bundle = new Bundle(1); // 파라미터는 전달할 데이터 개수
                bundle.putString("sep", itGet.getStringExtra("sep").toString()); // key , value
                fragment1.setArguments(bundle);
                transaction.replace(R.id.footer, fragment1);
                transaction.commit();
                break;

            case 2:
                // '프래그먼트2' 호출
                Header fragment2 = new Header();
                transaction.replace(R.id.header, fragment2);
                transaction.commit();
                break;
        }
    }

    public String TomcatConnector(String urlString) {

        StringBuilder html = new StringBuilder();
        try {
            URL url = new URL(urlString);

            HttpURLConnection conn = (HttpURLConnection)url.openConnection();

            if(conn != null)
            {
                conn.setConnectTimeout(3000);
                conn.setUseCaches(false);
                if(conn.getResponseCode() == HttpURLConnection.HTTP_OK)
                {
                    BufferedReader br =  new BufferedReader(new InputStreamReader(conn.getInputStream(),"utf-8"));

                    while (true)
                    {
                        String line = br.readLine();
                        if(line == null) break;
                        html.append(line+"\n");

                    }
                    br.close();
                }
                conn.disconnect();

            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return html.toString();

    }
}
